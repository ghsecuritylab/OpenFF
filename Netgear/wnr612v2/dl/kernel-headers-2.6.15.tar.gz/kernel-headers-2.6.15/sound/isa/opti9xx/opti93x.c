#define OPTi93X
#include "opti92x-ad1848.c"

