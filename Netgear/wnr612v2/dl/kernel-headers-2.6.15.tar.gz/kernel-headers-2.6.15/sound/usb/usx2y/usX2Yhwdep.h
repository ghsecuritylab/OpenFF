#ifndef USX2YHWDEP_H
#define USX2YHWDEP_H

int usX2Y_hwdep_new(snd_card_t* card, struct usb_device* device);

#endif
